/*=========== GLOBAL CONFIG ===========*/
// SCRIPT BY ICHANZX ID
// SORRY MASIH PEMULA KALO CODE NYA CACAD XIXI
// @_fake.story46
/*=========== GLOBAL CONFIG ===========*/
let fs = require('fs') 
let chalk = require('chalk')
// TEMPAT APIKEY BY IChanZX
global.apichan = 'IchanZX'
global.Apisichan = 'https://api-miftah.xyz'
// owner
global.namaowner = `Rava`
global.nomorowner = '6281232615640'
global.namabot = `ᴋᴏɴᴇᴋᴏ-ᴍᴅ`

global.thumb2 = fs.readFileSync('./media/thumbnail.mp4')
global.intro = 'https://i.ibb.co/W5Skvsw/IMG-20230824-WA0174.jpg'
global.fotobotnya = 'https://i.ibb.co/W5Skvsw/IMG-20230824-WA0174.jpg' // tempat foto tampilan menu
// BACA UNTUK MENJADIKAN FOTO JADI URL KIRIM .TOURL PADA BOT!!
global.wait = '_Chotto Matte Kudasai_'
owner = [
    ['6281212035575'],
  ['6281212035575'],
  ['6281212035575', 'My Names Rava', 'ravagrowtopia@gmail.com', true]
]  // Put your number here
// Put your number here
global.mods = [] // Want some help?
global.prems = ['6281212035575'] // Premium user has unlimited limit
/*=========== Panel ===========*/
global.domain = 'https://panelzxz123.zxcoderid.xyz' // Domain
global.apikey = 'ptla_81fG7XwYGzI3edWrNfnKgICYWRGGsvfogrc9K9xGL83'; // Key PTLA
global.c_apikey = 'ptlc_3o66pD32AiivN0coLPBiXwuqeFCBD5IbB9EzUiSnetn' // Key PTLC
global.eggs = '15'
global.locs = '1'
/*=========== store send testi ===========*/
global.jb1 = '120363163655682468' // ID GRUP LU CEK DI GROUPLIST
global.jb2 = '120363044850236202' // ID GRUP LU CEK DI GROUPLIST
/*=========== Harga reseller panel ===========*/
global.harga1gb = '10000'
global.harga2gb = '15000'
global.harga3gb = '20000'
global.harga4gb = '25000'
global.harga5gb = '30000'
global.harga6gb = '35000'
global.harga7gb = '40000'
global.hargaunli = '30000'
/*=========== Harga nokos wa ===========*/
global.nokosindo = '7000'
global.nokosusa = '8000'
global.nokosmalay = '12000'

/*=========== HIASAN MENU ===========*/
global.dmenut = '❏═┅═━–〈' // atas
global.dmenub = '┊•' // badan
global.dmenub2 = '┊' // bada pada default prefix nya
global.dmenuf = '┗––––––––––✦' // akhiran body
global.hiasan = '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷꒦'
global.cmenut = '––––––『' // Atas / atap
global.cmenuh = '』––––––' // Bawah body
global.cmenub = '┊☃︎ ' //body
global.cmenuf = '┗━═┅═━––––––๑\n' //footer
global.cmenua = '' //after
global.pmenus = '☃︎' //pembatas menu selector
global.htki = '––––『' 
global.htka = '』––––' 
global.lopr = 'Ⓟ'
global.lolm = 'Ⓛ'
global.htjava = '❃' 

// Sosial Media
global.sig = 'https://instagram.com/ravaja_'
global.syt = 'https://youtube.com/'
global.sgh = 'https://github.com/ravaachmad'
global.sgc = 'https://chat.whatsapp.com/GFtm25cVEmC1ZtqoCenClf'
global.swa = 'https://wa.me/+6281212035575'
global.swb = ''
global.snh = 'https://nhentai.net/g/365296/' //Make ini aja gausah di ganti.

// Pembayaran
global.pdana = '6281212035575'
global.povo = '6281212035575'
global.pgopay = '6281212035575'
global.pulsa = '6281212035575'
global.pulsa2 = '089513388950'
global.psaweria = 'https://saweria.co/Rava'
global.ptrakteer = 'https://trakteer.id/rava_achmad_fauzy?quantity=1'
global.psbuzz = 'https://sociabuzz.com/ravaja_'

// Sticker WM
packname = sticker_name
author = sticker_author
wm = '© ᴋᴏɴᴇᴋᴏ-ᴍᴅ'

Intervalmsg = 1800 //detik
multiplier = 1000 // Tinggi Level Up
/*============== API ==============*/
APIs = { // API Prefix
  // name: 'https://website'
  nrtm: 'https://nurutomo.herokuapp.com',
  xteam: 'https://api.xteam.xyz',
  zahir: 'https://zahirr-web.herokuapp.com',
  bcil: 'https://75.119.137.248:21587',
  neoxr: 'https://api.neoxr.eu.org/',
  zeks: 'https://api.zeks.me',
  gimez: 'https://masgimenz.my.id/',
  melcanz: 'https://melcanz.com',
  erdwpe : 'https://api.erdwpe.com',
  pencarikode: 'https://pencarikode.xyz',
  LeysCoder: 'https://leyscoders-api.herokuapp.com',
  restapi: 'https://x-restapi.herokuapp.com',
  xzn : 'https://skizo.tech',
  dnz: 'https://danzzapi.xyz',
  males: 'https://malesin.xyz',
  lol: 'https://api.lolhuman.xyz/'
}

APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'apikeyaine',
  'https://zahirr-web.herokuapp.com': 'zahirgans',
  'https://api.lolhuman.xyz/': 'ichanzx', 
  'https://api.neoxr.eu.org/': 'jVEMyB2ITJ',
  'https://api.zeks.me': 'apikeyaine',
  'https://pencarikode.xyz': 'pais',
  'https://melcanz.com': 'ZZBk7EBb',
  'https://skizo.tech': 'ravaja',
  'https://leyscoders-api.herokuapp.com': 'dappakntlll',
  'https://x-restapi.herokuapp.com': 'BETA',
  'https://danzzapi.xyz': 'danzz'
}

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0

const spack = fs.readFileSync("lib/exif.json")
const stickerpack = JSON.parse(spack)
if (stickerpack.spackname == '') {
  var sticker_name = namabot
  var sticker_author = 'ᴋᴏɴᴇᴋᴏ-ᴍᴅ'
} else {
  var sticker_name = stickerpack.spackname
  var sticker_author = stickerpack.sauthor
}

const file_exif = "lib/exif.json"
fs.watchFile(file_exif, () => {
  fs.unwatchFile(file_exif)
  console.log(chalk.redBright("Update 'exif.json'"))
  delete require.cache[file_exif]
  require('./lib/exif.json')
})
rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      exp: '✉️',
      money: '💵',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      pet: '🎁',
      trash: '🗑',
      armor: '🥼',
      sword: '⚔️',
      wood: '🪵',
      rock: '🪨',
      string: '🕸️',
      horse: '🐎',
      cat: '🐈' ,
      dog: '🐕',
      fox: '🦊',
      petFood: '🍖',
      iron: '⛓️',
      gold: '👑',
      emerald: '💚'
    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
