var handler = async (m, {
	text,
	conn
}) => {
	if (!text) throw 'Perihal Apah?'
	var url = text.replace(/\s+/g, '+')
	try {
        //https://vihangayt.me/download/instagram?url=
		/*var response = await fetch(API('xzn', 'api/igdl', {
			url
		}, 'apikey'))*/
		var response = await fetch(`https://api.lolhuman.xyz/api/instagram?apikey=IchanZX&url=${url}`)
        //var response = await fetch(`https://api.yanzbotz.my.id/api/downloader/instagram?url=${url}`) 
		var wtf = await response.json()
		for (var i = 0; i < wtf.media.length; i++) {
			var caption = i == 0 ? wtf.caption : ''
			var type = wtf.media[i].includes('.jpg') ? 'image' : 'video'
			await conn.sendMessage(m.chat, {
				[type]: {
					url: wtf.media[i]
				},
				caption
			}, {
				quoted: m
			})
			await delay(1500)
		}
	} catch (e) {
		console.error(e)
        m.reply('server error!')
        conn.reply('6281212035575' + '@s.whatsapp.net', e, m)
		throw e.toString()
	}
}
handler.help = ['instagram']
handler.tags = ['downloader']
handler.command = /^(instagram|igdl|ig|instagramdl)$/i
handler.limit = true

module.exports = handler
  function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }