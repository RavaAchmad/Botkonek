/*let fs = require('fs')
const { MessageType } = require('@adiwajshing/baileys')
let handler = async (m) => {
let helloaine = fs.readFileSync('./mp3/PTT-20211218-WA0243.opus') 
conn.sendFile(m.chat, helloaine, '', '', m, true)
}

handler.customPrefix = /^(i love you|i ❤️ u)$/i
handler.command = new RegExp

handler.limit = true
handler.mods = false 
handler.premium = false
handler.group = true
handler.private = false

module.exports = handler*/
